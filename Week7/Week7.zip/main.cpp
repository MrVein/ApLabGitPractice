#include <iostream>
#include "Header Files/graph.h"

int main()
{
    graph<int , 10> test;

    cout << test.find(19);



    return 0;
}
