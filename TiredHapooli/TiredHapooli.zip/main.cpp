#include <iostream>
#include <vector>
#include <cassert>
#include <cstring>
#include "Header Files/matrix.h"
using namespace std;

//class template



int main()
{
//    matrix<int> test2({{1 , 2 , 3} , {3 ,4 ,6}});
//    test2.matrix_cout();

//    char* hello;
//    char* hello2;
//    char* hello3;
//    char* hello4;
//
//    char destination[] = "Hello ";
//    char source[] = "World!";

//    strcat(destination,source);
//
//    cout << destination << endl;
//    sosmas.matrix_cout();
//

//    matrix<char*> hi({{destination , source} , {source , destination}});
//    hi.matrix_cout();
//    (hi.concatenate(hi)).matrix_cout();

    matrix<int> m;
    cin >> m;

    return 0;
}
