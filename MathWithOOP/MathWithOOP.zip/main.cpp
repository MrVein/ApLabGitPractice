#include <iostream>
#include "Header Files/polynomial.h"

int main()
{
    polynomial p;

    return 0;
}
